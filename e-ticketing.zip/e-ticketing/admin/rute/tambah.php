<?php

session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

if(isset($_POST["tambah"])){
    if(tambah($_POST) > 0 ){
        echo "
            <script type='text/javascript'>
                alert('Yay! data rute berhasil ditambahkan!')
                window.location = 'index.php'
            </script>
        ";
    }else{
        echo "
            <script type='text/javascript'>
                alert('Yhaa .. data rute gagal ditambahkan :(')
                window.location = 'index.php'
            </script>
        ";
    }
}

$maskapai = query("SELECT * FROM maskapai");
$kota = query("SELECT * FROM kota");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<style>
    body{
        background: #eee;
    }
    .container-tambah{
        background: #fff;
        padding: 10px;
        border-radius: 5px;
        margin: 25px auto;
        margin-left: 280px;
        width: 75%;
    }
</style>

    <div class="container-tambah">
        <div class="bg-gray-600 p-10 my-10">
            <h1 class="text-2xl font-bold mb-3">Tambah Rute</h1>

            <form action="" method="POST">
                <label for="nama_maskapai">Nama Maskapai</label><br />
                <select name="id_maskapai" id="id_maskapai" class="">
                    <?php foreach($maskapai as $data) : ?>
                    <option value="<?= $data["id_maskapai"]; ?>"><?= $data["nama_maskapai"]; ?></option>
                    <?php endforeach; ?>
                </select><br /> <br />

                <label for="rute_asal">Rute Asal</label><br />
                <select name="rute_asal" id="rute_asal" class="">
                    <?php foreach($kota as $data) : ?>
                    <option value="<?= $data["nama_kota"]; ?>"><?= $data["nama_kota"]; ?></option>
                    <?php endforeach; ?>
                </select><br /> <br />

            
                <label for="rute_tujuan">Rute Tujuan</label><br />
                <select name="rute_tujuan" id="rute_tujuan" class="">
                    <?php foreach($kota as $data) : ?>
                    <option value="<?= $data["nama_kota"]; ?>"><?= $data["nama_kota"]; ?></option>
                    <?php endforeach; ?>
                </select><br /> <br />

                <label for="tanggal_pergi">Tanggal Pergi</label><br />
                <input type="date" name="tanggal_pergi" id="tanggal_pergi" class=""><br /><br />

                <button type="submit" name="tambah" class="">Tambah</button>
            </form>
        </div>
    </div>
