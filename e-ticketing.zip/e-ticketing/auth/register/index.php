<!DOCTYPE html>
   <html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.css" crossorigin="">
      <link rel="stylesheet" href="style.css">

      <title>Register form</title>
   </head>
   <body>
      <div class="login">
         <img src="../../assets/images/logo.png" alt="image" class="login_bg">

         <form action="process.php" method="POST">
            <h1 class="login_title">Login</h1>

            <div class="login_inputs">
               <div class="login_box">
                  <input type="text" placeholder="username ID" name="username" id="username" required class="login_input" >
                  <i class="ri-user-add-fill"></i>
               </div>

               <div class="login_box">
                  <input type="text" placeholder="Nama lengkap" name="nama_lengkap" id="nama_lengkap" required class="login_input" >
                  <i class="ri-user-6-line"></i>
               </div>

               <div class="login_box">
                  <input type="password" placeholder="Password" required class="login_input" type="password" name="password" id="password" >
                  <i class="ri-lock-2-fill"></i>
               </div>
            </div>

            <button type="submit" class="login_button">Register</button><br><br>

            <div class="login_register">
               do you alredy account? <a href="../login/">Login</a>
            </div>
         </form>
      </div>
   </body>
</html>